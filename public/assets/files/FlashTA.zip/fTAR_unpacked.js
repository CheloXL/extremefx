var fTAR = {};
fTAR.FlashObject = function(_pFile, _pID){
	var $ = this;
	$._vars = [];
	$._params = [];
	$._movie = _pFile;
	$._ID = _pID || 'efx_fo_'+fTAR.FlashObject._counter++;
	$.addParam('allowScriptAccess', 'always');
	$.addVar('flashID', $._ID);
	$._width = $._height = 0;
};

fTAR.FlashObject._counter = 0;
fTAR.FlashObject._isPlugin = (navigator.plugins && navigator.mimeTypes && navigator.mimeTypes.length);
fTAR.FlashObject._isIE = window.ActiveXObject || false;

fTAR.FlashObject._playerVersion = function(){
	var pv = {major:0, minor:0, rev:0};
	var va = [0,0,0];
	if(fTAR.FlashObject._isPlugin){
		var x = navigator.plugins['Shockwave Flash'];
		if(x && x.description) {
			va = x.description.replace(/([a-z]|[A-Z]|\s)+/, '').replace(/(\s+r|\s+b[0-9]+)/, '.').split('.');
		}
	} else if (fTAR.FlashObject._isIE){
		try {
			var axo = new ActiveXObject('ShockwaveFlash.ShockwaveFlash');
			axo.allowScriptAccess = 'always';
			va = axo.GetVariable('$version').split(' ')[1].split(',');
		} catch (e) {
		}
	}

	pv.major = parseInt(va[0]) || 0;
	pv.minor = parseInt(va[1]) || 0;
	pv.rev = parseInt(va[2]) || 0;

	return pv;
}();

fTAR.FlashObject.versionIsValid = function(_required){
	var _current = fTAR.FlashObject._playerVersion;

	if (_required.major > _current.major) return false;
	if (_required.major < _current.major) return true;
	if (_required.minor > _current.minor) return false;
	if (_required.minor < _current.minor) return true;
	return (_required.rev <= _current.rev);
};

fTAR.FlashObject.prototype = {
	setSize:function(_pW, _pH){
		this._width = _pW;
		this._height = _pH;
	},

	_getFlashNode:function(){
		var _element = document.getElementById(this._ID);
		if (fTAR.FlashObject._isIE) {
			window[this._ID] = _element;
		}

		return _element;
	},

	insert:function(_pNode, _pOuter){
		if (typeof _pNode == 'string') {
			_pNode = document.getElementById(_pNode);
		};

		var _code = this._getCode();

		if (_pOuter){
			if (fTAR.FlashObject._isIE){
				_pNode.outerHTML = _code;

			} else {
				var _newNode = document.createElement('div');
				document.getElementsByTagName('body')[0].appendChild(_newNode);
				_newNode.innerHTML = _code;
				_pNode.parentNode.replaceChild(document.getElementById(this._ID), _pNode);
			}

		} else {
			_pNode.innerHTML = _code;
		}

		return this._getFlashNode();
	},

	_getCode:function(){
		this.addParam('FlashVars', this._getFlashVars());

		var $flashnode = '<object id="'+ this._ID +'" width="'+ this._width +'" height="'+ this._height +'"';

		if (fTAR.FlashObject._isPlugin) { // netscape plugin architecture
			$flashnode += ' type="application/x-shockwave-flash" data="'+this._movie+'">';

		} else if (fTAR.FlashObject._isIE){ // PC IE
			$flashnode += ' classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000">';
			this.addParam('movie', this._movie);
		}

		for(var $i in this._params) {
			$flashnode += '<param name="'+ $i +'" value="'+ this._params[$i] +'" />';
		}

		$flashnode += '</object>';
		return $flashnode;
	},

	addParam:function (_name, _value){
		this._params[_name] = _value;
	},

	addVar:function (_name, _value){
		this._vars[_name] = _value;
	},

	_getFlashVars:function(){
		var $tfvars = [];
		for (var $i in this._vars){
			$tfvars[$tfvars.length] = $i +'='+ encodeURIComponent(this._vars[$i]);
		}

		return $tfvars.join('&');
	}
};

fTAR.FlashTextArea = new function(){
	var $ = this;

	var _replacedTextAreas = [];
	var _selStates;
	var _inited = false;
	var _fileBrowserObject;
	var _fileBrowserOpen = false;
	var _textareaURL;
	var _fileManager;
	var _serverURL;
	var _basePath;
	var _langFile;
	var _useBrowser = true;
	var _body, _fontFamily, _baseFontSize;
	var _bckColor = '#E9EBEE';

	var _createElement = function(el) {
		return document.createElement(el);
	};

	var _addEventListener = function(_pElement, _pEvent, _Fnc){
		if (_pElement.addEventListener){
			_pElement.addEventListener(_pEvent, _Fnc, false);

		} else if (_pElement.attachEvent){
			_pElement.attachEvent('on'+_pEvent, _Fnc);

		} else {
			return false;
		}
	};

	/**
	 * Returns an array of all the areas who's contents were modified, or false if no area were modified.
	 */

	$.getChangedAreas = function(){
		var _changedAreas = [];
		var _changed = false;
		for (var i in _replacedTextAreas){
			if ($.hasChanged(i)) {
				_changedAreas.push(i);
				_changed = true;
			}
		}

		return _changed ? _changedAreas : _changed;
	};

	/**
	 * Test if the contents of area named _pNode has changed
	 */
	$.hasChanged = function(_pNode){
		return _replacedTextAreas[_pNode].fl.hasChanged();
	};

	/**
	 * Gets the contents of the original text area.
	 * Called from flash
	 */
	$.getTextAreaContent = function(_pNode){
		return _replacedTextAreas[_pNode].tf.value;
	};

	/**
	 * Sets the content of all the replaced text areas with the content from the flash object.
	 */
	$.updateContent = function (){
		var _flash;
		try {
			for (var i in _replacedTextAreas){
				var _cta = _replacedTextAreas[i];
				if (typeof _cta.fl.getContents == 'function') {
					_cta.tf.value = _cta.fl.getContents();
				}
			}
		} catch (e){}
	};

//
	/**
	 * Opens the File/Image browser window
	 */
	var _doBrowse = function(_pField, _pFromFlash, _imgs){
		if (_fileBrowserOpen) {
			$.closeBrowse();
		}

		_fileBrowserOpen = true;

		if (!_pFromFlash){
			_pField = _pField.split(',');
			_imgs = _pField[1];
			_pField = _pField[0];
		}
		
		_fileBrowserObject = efx.Browser.open("fileBrowser.html?imagesOnly="+(_imgs || false)+"&fromFlash="+(_pFromFlash || false)+"&browseElementID="+_pField, 750, 450);
	};

	/**
	 * Called from flash (textareas) to open the file browser.
	 */
	$.flashBrowse = function(_pFlashID, _pImages){
		_doBrowse(_pFlashID, true, _pImages);
	};
	
	/**
	 * Called from the opened window to insert the selected file
	 */
	$.insertFile = function(_pField, _file, _width, _height, _pFromFlash){
		if (_pFromFlash && _pFromFlash=='true'){
			_replacedTextAreas[_pField].fl.insertFile(_file, _width, _height);

		} else {
			var el = document.getElementById(_pField);
			el.value = _file;
		}

		$.closeBrowse();
	};

	/**
	 * Closes the browser window
	 */
	$.closeBrowse = function(){
		_fileBrowserObject.close();
		_fileBrowserOpen = false;
	};

	var _getListOfReplacements = function(_element, _class){
		var _list = [], _node;
		var _elements = document.getElementsByTagName(_element);
		var _regex = new RegExp('\\b'+_class+'\\b');

		for (var j = 0, _limit = _elements.length; j < _limit; j++){
			if ((_node = _elements[j]).className.match(_regex)) {
				_list.push(_node);
			}
		}

		return _list;
	};

	var _replaceInputs = function(){
		var _listNodes = _getListOfReplacements('input', 'efx_browser');
		_listNodes = _listNodes.concat(_getListOfReplacements('input', 'efx_browser_images'));
		if(_listNodes.length == 0){ return false };

		var _limit, _node, _parent, _dupNode, _newNode, _click, id;

		for(var i = 0, _limit = _listNodes.length; i < _limit; i++){
			_node = _listNodes[i];
			_parent = _node.parentNode;

			_dupNode = _node.cloneNode(true);

			id = _node.getAttribute('id');
			_newNode = _createElement('span');
			_newNode.className = 'efx_form_fileBrowser_span';

			_newNode.appendChild(_dupNode);

			if (id == undefined || id == ''){
				id = '__browser__'+i;
				_dupNode.setAttribute('id', id);
			}

			_click = _createElement('a');
			_click.className = 'efx_form_fileBrowser_button';
			_click.setAttribute('rel', id+','+(_node.className.indexOf('efx_browser_images') != -1));
			_click.appendChild(document.createTextNode('Browse...'));

			_newNode.appendChild(_click);
			_parent.replaceChild(_newNode, _node);

			_addEventListener(_click, 'click', function(e){
				_doBrowse((e.target || e.srcElement).getAttribute('rel'));
				return false;
			});
		}
	};

	var _replaceTextAreas = function(){
		var _listNodes = _getListOfReplacements('textarea', 'efx_flashtextarea');
		if(_listNodes.length == 0){ return false }

		for(var i = 0, _limit = _listNodes.length; i < _limit; i++){
			var _textarea = _listNodes[i];
			var _taParent = _textarea.parentNode;
			
			var _taContent = _textarea.value;
			var _taName = _textarea.getAttribute('name');
			var _taID = _textarea.getAttribute('id') || _taName;

			var _flashID = 'fTAR_'+_taID;
			var _taWidth = _textarea.offsetWidth;
			var _taHeight = _textarea.offsetHeight;

			if (_taWidth < 550) _taWidth = 550;
			if (_taHeight < 400) _taHeight = 400;

			var _flashObject = new fTAR.FlashObject(_textareaURL, _flashID);
			_flashObject.addVar('useBrowser', _useBrowser);
			_flashObject.addVar('textfieldName', encodeURIComponent(_taName));
			_flashObject.addVar('buttons', fTAR.FlashTextAreaButtons.buttons);
			_flashObject.addVar('lang', _langFile);
			
			if (_fontFamily) _flashObject.addVar('fontFamily', _fontFamily);
			if (_baseFontSize) _flashObject.addVar('baseFontSize', _baseFontSize);

			//_flashObject.addParam('wmode', 'opaque');
			_flashObject.addParam('bgcolor', _bckColor);
			
			_flashObject.setSize(_taWidth, _taHeight);

			var _flashNode = _flashObject.insert(_textarea, true);
			_flashNode.className = 'efx_form_flashtextarea';

			var _hiddenInput = _createElement('input');
			_hiddenInput.setAttribute('type', 'hidden');
			_hiddenInput.setAttribute('name', _taName);
			_hiddenInput.setAttribute('id', _taID);
			_hiddenInput.setAttribute('value', _taContent);

			_taParent.appendChild(_hiddenInput);
			_replacedTextAreas[_taName] = {tf:_hiddenInput, fl:_flashNode};
		}
		
		var _forms = document.forms;
		//Sets the content of all the replaced text areas with the content from the flash object on form submission
		for (var i = 0, l = _forms.length; i<l; i++){
			_addEventListener(_forms[i], 'submit', $.updateContent);
		}
	};
	
	$.setBackgroundColor = function(_pBckColor) {
		_bckColor = _pBckColor;
	};
	
	$.setFontFamily = function(_pFFamily) {
		_fontFamily = _pFFamily;
	};
	
	$.setBaseFontSize = function(_pBFSize) {
		_baseFontSize = _pBFSize;
	};

	$.setServerURL = function(_s_serverURL) {
		_serverURL = _s_serverURL;
	};

	$.setFilemanager = function(_sFManagerUrl) {
		_fileManager = _sFManagerUrl;
	};

	$.setBasePath = function(_bp){
		_basePath = _bp;
	};

	$.setLngFile = function(_pFile){
		_langFile = _pFile;
	};

	$.useFileBrowser = function(_pUse){
		_useBrowser = _pUse;
	};

	var _init = function(){
		if (_inited) return;
		_inited = true;

		setTimeout(function(){
			if (fTAR.FlashObject.versionIsValid({major:8, minor:0, rev:0})){
				_body = document.getElementsByTagName('body')[0];

				

				_replaceTextAreas();
				_replaceInputs();
			}
		}, 10);
	};

	$.setup = function(_eurl){
		if (_inited) return;
		_textareaURL = _eurl;
		_addEventListener(window, 'load', _init);
	}

}();

fTAR.FlashTextAreaButtons = new function(){
	var $ = this;
	$.buttons = 0x7FFFF;

	$._setBits = function(_pVal, _pBit){
		if (_pVal){
			$.buttons |= _pBit;

		} else {
			$.buttons &= ~_pBit;
		}
	};

	$.bold = function(_pVal){
		$._setBits(_pVal, 1);
	};

	$.italic = function(_pVal){
		$._setBits(_pVal, 2);
	};

	$.underline = function(_pVal){
		$._setBits(_pVal, 4);
	};

	$.leftAlign = function(_pVal){
		$._setBits(_pVal, 8);
	};

	$.centerAlign = function(_pVal){
		$._setBits(_pVal, 16);
	};

	$.rightAlign = function(_pVal){
		$._setBits(_pVal, 32);
	};

	$.justifyAlign = function(_pVal){
		$._setBits(_pVal, 64);
	};

	$.header1 = function(_pVal){
		$._setBits(_pVal, 128);
	};

	$.header2 = function(_pVal){
		$._setBits(_pVal, 256);
	};

	$.header3 = function(_pVal){
		$._setBits(_pVal, 512);
	};

	$.header4 = function(_pVal){
		$._setBits(_pVal, 1024);
	};

	$.header5 = function(_pVal){
		$._setBits(_pVal, 2048);
	};

	$.header6 = function(_pVal){
		$._setBits(_pVal, 4096);
	};

	$.bullets = function(_pVal){
		$._setBits(_pVal, 8192);
	};

	$.quote = function(_pVal){
		$._setBits(_pVal, 16384);
	};

	$.links = function(_pVal){
		$._setBits(_pVal, 32768);
	};

	$.images = function(_pVal){
		$._setBits(_pVal, 65536);
	};

	$.undo = function(_pVal){
		$._setBits(_pVal, 131072);
	};

	$.redo = function(_pVal){
		$._setBits(_pVal, 262144);
	}
}();

var efx = {};
efx.Query = new function(){
	var $ = this;
	$.get = function(_s){
		if(!(_s = _s || location.search)) return null;
    	var v, f, i, a = {}, r = /\+/g, u = unescape;
    	if(_s = _s.split("?")[1]){
	        for(i = (_s = _s.split("&")).length; i;){
	            (v = u((f = _s[--i].split("="))[1].replace(r, " ")), a[f[0]] !== undefined)
	            && (a[f[0]] instanceof Array ? a[f[0]] : a[f[0]] = [a[f[0]]]).push(v)
	            || (a[f[0]] = v);
	        }
    	}
	    return a;
	}
}();

efx.Browser = new function(){
	var $ = this;
	$.open = function(_url, _width, _height){
		var _wl = (screen.width - _width) / 2;
		var _wt = (screen.height - _height) / 2;
		
		var _obj = window.open(_url, '', 'top='+_wt+',left='+_wl+',alwaysRaised=1,directories=0,innerHeight='+_height+',height='+_height+',innerWidth='+_width+',width='+_width+',location=0,menubar=0,resizable=0,scrollbars=0,status=0,toolbar=0');
		if (parseInt(navigator.appVersion) >= 4) setTimeout(_obj.window.focus, 100);
		return _obj;
	}
}();

if(typeof fTAR == 'object'){
	var _fileManager = 'fileManager.php';
	var _serverURL = 'http://localhost';
	var _basePath = '';
	var _lngFile = 'lang/es.xml';
	
	if (window.opener){
		var fileBrowser = new fTAR.FlashObject('FlashFB.swf', 'FlashBrowserObject');
		fileBrowser.setSize(750, 450);
		fileBrowser.addVar('script',_fileManager);
		fileBrowser.addVar('serverurl',_serverURL);
		fileBrowser.addVar('basepath',_basePath);
		fileBrowser.addVar('lang', _lngFile);

	} else {
		fTAR.FlashTextArea.setFilemanager(_fileManager);
		fTAR.FlashTextArea.setServerURL(_serverURL);
		fTAR.FlashTextArea.setBasePath(_basePath);
		fTAR.FlashTextArea.setLngFile(_lngFile);
	
	//	fTAR.FlashTextArea.setBackgroundColor('ff0000');
	//	fTAR.FlashTextArea.setFontFamily('Tahoma, Arial, Verdana');
	//	fTAR.FlashTextArea.setBaseFontSize(12);
		
		fTAR.FlashTextArea.setup('FlashTA.swf');	
	}
}