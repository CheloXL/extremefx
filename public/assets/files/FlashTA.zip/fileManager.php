<?php
/**
 * Author: Marcelo Volmaro
 * http://www.extremefx.com.ar
 * Created on Oct 3, 2005
 */

/**
 * Configurable options
 */

$config = array(
	'diskPath'=>'c:/www/',
	'thumbPath'=>'',

	'ftpPath'=>'',
	'ftpServer'=>'',
	'ftpUser'=>'',
	'ftpPass'=>'',
);

/**
 * Do not change anything below this line!!
 */

class FileManager {
	var $sysPath;
	var $ftpPath;
	var $ftpServer;
	var $ftpUser;
	var $ftpPass;

	var $_fixTS;
	var $_buffer;

	var $kinds = Array(
			'sound'=>Array('wav','mp3','ogg','mid','aif','aiff'),
			'image'=>Array('jpg','jpeg','png','gif','tif','tiff','bmp'),
			'video'=>Array('avi','mpg','qt','rm'),
			'generic'=>Array()
		);

	function FileManager($config){
		$this->sysPath = $config['diskPath'];
		$this->ftpPath = $config['ftpPath'];
		$this->ftpServer = $config['ftpServer'];
		$this->ftpUser = $config['ftpUser'];
		$this->ftpPass = $config['ftpPass'];

		$this->_fixTS = (date('I') == 1) ? -3600 : 0;
	}

	function buildFilename($path, $file){
		$file = trim($file);
		if ($file == '') return false;

		$path = $this->_normalize($path, false);
		if (!is_dir($path)) return false;

		return $path . $file;
	}

	function getDirList($path, $recurse = false, $only = null) {
		$path = $this->_normalize($path, false);
		return $this->_recurseList($path, $recurse, $only);
	}

	function _recurseList($path, $recurse, $only){
		if (!is_dir($path)) return;

		$ret = array();

		if($contents = opendir($path)) {
			while(($node = readdir($contents)) !== false) {
				if($node != '.' && $node != '..' && $node[0] != '.' ) {
					$currentItem = $path . '/' . $node;
					$s = stat($currentItem);

					if(is_dir($currentItem)){
						$res = array(
							'kind'=>'folder',
						);

						if ($recurse){
							$res['childs'] = $this->_recurseList($currentItem, true, $only);

						} else {
							$a = $this->_countFF($currentItem);
							$res['files'] = $a['files'];
							$res['folders'] = $a['folders'];
						}

					} else {
						$extension = strtolower(substr(strrchr($node, '.'), 1));

						foreach ($this->kinds as $key=>$kind){
							if (in_array($extension, $kind)) break;
						}

						if ($only != null && $only != $key) continue;

						$res = array(
							'ext'=>strtolower($extension),
							'kind'=>$key,
							'size'=>filesize($currentItem),
						);
					}

					$res['name'] = $node;
					$res['atime'] = $s['atime']+$this->_fixTS;
					$res['mtime'] = $s['mtime']+$this->_fixTS;

					$ret[] = $res;
				}
			}
			closedir($contents);
		}

		return $ret;
	}

	function _countFF($path){
		$counts = array('files'=>0, 'folders'=>0);
		if ($contents = opendir($path)){
			while(($node = readdir($contents)) !== false) {
				$currentItem = $path . '/' . $node;
				if($node != '.' && $node != '..' && $node[0] != '.' ) {
					if(is_dir($currentItem)){
						$counts['folders']++;

					} else {
						$counts['files']++;
					}
				}
			}
		}

		return $counts;
	}

	function upload($path){
		$path = $this->_normalize($path, false);
		if (!is_dir($path)) return;

		foreach ($_FILES as $file){
			if ($file['error'] == 0 && $file['size'] != 0){
				$realFilename = $this->_cleanFilename($file['name']);

				if(preg_match("/.exe$|.com$|.bat$|.php$|.asp$|.jsp$|.htm$/i", $realFilename)) exit('invalid extension');
				if ($realFilename == "") exit('invalid filename');

				$filename = $path . $realFilename;
				$exist = file_exists($filename);

				if ($exist){
					$oldFile = $filename;
					$newFile = $this->sysPath . md5(microtime());
					rename($oldFile, $newFile);
				}

				$result = move_uploaded_file($file['tmp_name'], $filename);

				if ($result){
					if (!chmod($filename, 0755)){
						$result = false;
					}
				}
			}

			if ($exist){
				if ($result){
					@unlink($newFile);

				} else {
					@unlink($filename);
					@rename($newFile, $oldFile);
				}
			}
		}
	}

	function createFolder($path, $dir){
		$dir = $this->_cleanFilename($dir);

		if ($dir == '') return false;

		$path = $this->_normalize($path, false);

		if (!is_dir($path)) return false;

		if(ini_get('safe_mode')){
	 		$connection = ftp_connect($this->ftpServer);
			$result = ftp_login($connection, $this->ftpUser, $this->ftpPass);

			if ((!$connection) || (!$result)) {
				return false;

	  		} else {
				ftp_chdir($connection, dirname($this->ftpPath .$path));
				$result = ftp_mkdir($connection, $dir);

				if ($result){
					$chmod = ftp_site($connection, "CHMOD 0777 $dir");
				}

				ftp_close($connection);
				return $result;
			}

		} else {
			$oldumask = umask(0);
			$r = (bool) mkdir($path.$dir, 0777);
			umask($oldumask);
			return $r;
		}
	}

	function delete($path, $files) {
		$path = $this->_normalize($path, false);
		if (!is_dir($path)) return;

		if (!is_array($files)) $files = array($files);
		$ret = true;

		foreach ($files as $file){
			$cfile = $path . $file;

			if (file_exists($cfile)){
				if (is_dir($cfile)) {
					@rmdir($cfile);

				} else {
					@unlink($cfile);
				}
			}
		}
	}

	function download($path, $file){
		$file = trim($file);
		if ($file == '') return false;

		$path = $this->_normalize($path, false);
		if (!is_dir($path)) return false;

		$filename = $path . $file;
		$shortname = basename($filename);

		if(file_exists( $filename ) && !eregi( "inc", $filename ) && !eregi( "php?", $filename ) ){
			$size = filesize($filename);
			header('Content-Type: application/save');
			header("Content-Disposition: attachment; filename=$shortname");
			header("Content-length: $size");
			@readfile("$filename");
		}
		exit;
	}

	function _normalize($path, $strict = true){
		$path = preg_replace('/&.+?;/', '', $path); // kill entities

		if ($strict){
			$path = str_replace( '_', '-', $path );
			$path = preg_replace('/[^a-z0-9\s-.]/', '', $path); //only a-z, 0-9, space, - and .
			$path = preg_replace('/\s+/', '-', $path);// multiple spaces with -
			$path = preg_replace('|-+|', '-', $path);
			$path = trim($path, '-');
		}

		$path = str_replace( './', '', str_replace( '../', '', $this->sysPath . $path ));
		$path = preg_replace('/\\\/', '/', $path);
		while (strpos($path, '//')) $path = str_replace( '//', '/', $path );
		return rtrim($path, '/') . '/';
	}

	function _cleanFilename($filename) {
		$bad = array( '<!--', '-->', "'", '<', '>', '"', '&', '$', '=', ';', '?', '/', "%20", "%22", "%3c", "%253c", "%3e", "%0e", "%28", "%29", "%2528", "%26", "%24", "%3f", "%3b", "%3d");

		$filename = str_replace('\\','',$filename);

		foreach ($bad as $val) {
			$filename = str_replace($val, '', $filename);
		}

		$filename = trim($filename);
		$filename = preg_replace("/\s+/", "_", $filename);
		return $filename;
	}

	function txt_info($path, $filename, $lines = 4) {
		$filename = trim($filename);
		if ($filename == '') return;

		$path = $this->_normalize($path, false);
		if (!is_dir($path)) return;

		$open = fopen($path . $filename, 'rb' );
 		$open_data = array();
		$line=0;

		while(!feof($open)){
			$txt = rtrim(fgets($open), "\r\n \r");
			if (trim($txt) != '') $open_data[$line++] = $txt;
			if( $line >= $lines ) break;
		}

		fclose($open);
		return $open_data;
	}

	function swf_info($path, $filename) {
		$filename = trim($filename);
		if ($filename == '') return;

		$path = $this->_normalize($path, false);
		if (!is_dir($path)) return;

		$fp = @fopen($path . $filename,'rb');
		$valid = false;

		if ($fp) {
			$csize = filesize ($path . $filename);
			$magic = fread($fp,3);

			if ($magic=='FWS' || $magic=='CWS') {
				$compressed = substr($magic,0,1)== 'C';
				$version = ord(fread($fp,1));

				$lg = 0;
				for ($i=0;$i<4;$i++) {
					$t = ord(fread($fp,1));
					$lg += ($t<<(8*$i));
				}

				$size = $lg;
				$buffer = fread($fp, $size);

				if ($compressed) {
					$buffer = gzuncompress($buffer, $size);
				}

				$b		= ord(substr($buffer,0,1));
				$buffer = substr($buffer,1);
				$cbyte 	= $b;
				$bits 	= $b>>3;
				$cval 	= '';
				$cbyte &= 7;
				$cbyte<<= 5;
				$cbit 	= 2;

				for ($vals=0;$vals<4;$vals++) {
					$bitcount = 0;

					while ($bitcount<$bits) {
						if ($cbyte&128) {
							$cval .= '1';
						} else {
							$cval.= '0';
						}

						$cbyte<<=1;
						$cbyte &= 255;
						$cbit--;
						$bitcount++;

						if ($cbit<0) {
							$cbyte	= ord(substr($buffer,0,1));
							$buffer = substr($buffer,1);
							$cbit = 7;
						}
					}

					$c = 1;
					$val = 0;
					$tval = strrev($cval);
					for ($n=0;$n<strlen($tval);$n++) {
						$atom = substr($tval,$n,1);
						if ($atom=='1') $val+=$c;
						$c*=2;
					}

					$val/=20;
					switch ($vals) {
						case 0:
							$width = $val;
						break;
						case 1:
							$width = $val - $width;
						break;
						case 2:
							$height = $val;
						break;
						case 3:
							$height = $val - $height;
						break;
					  }
					$cval = '';
				  }

				$fps = Array();
				for ($i=0;$i<2;$i++) {
					$t = ord(substr($buffer,0,1));
					$buffer = substr($buffer,1);
					$fps[]= $t;
				}

				$fps = $fps[1] . '.' . $fps[0];

				$frames = 0;
				for ($i=0;$i<2;$i++) {
					$t = ord(substr($buffer,0,1));
					$buffer = substr($buffer,1);
					$frames += ($t<<(8*$i));
				}
				fclose($fp);
				$valid =  true;
			}
		}

		return array(
			'valid'=>$valid,
			'magic'=>$magic,
			'compressed'=>$compressed,
			'version'=>$version,
			'fsize'=>$size,
			'csize'=>$csize,
			'width'=>$width,
			'height'=>$height,
			'fps'=>$fps,
			'frames'=>$frames
		);
	}

	function img_info($path, $filename) {
		$filename = trim($filename);
		if ($filename == '') return;

		$path = $this->_normalize($path, false);
		if (!is_dir($path)) return;

		$info = getimagesize($path . $filename);

		$types = array(null, 'gif','jpg','png','swf','psd','bmp','tif','tif','jpc','jp2','jpx','jb2','swc','iff','wbmp','xbm');

		$ret = array(
			'width'=>$info[0],
			'height'=>$info[1],
			'type'=>$types[$info[2]]
		);

		if (isset($info['bits'])) $ret['bits'] = $info['bits'];
		if (isset($info['channels'])) $ret['channels'] = $info['channels'];
		if (isset($info['mime'])) $ret['mime'] = $info['mime'];
		return $ret;
	}
}

class ImageManagement {
	function layerAdd(&$source, &$target, $tx, $ty){
//		imagealphablending($target, true);
		imagecopy($target, $source, $tx, $ty, 0, 0, imagesx($source),imagesy($source));
	}

	function &slice9rect(&$im, $startX, $startY, $lenX, $lenY, $width, $height){
		$sw = imagesx($im);
		$sh = imagesy($im);

		$sliced = imagecreatetruecolor ($width, $height);

		imagealphablending($sliced, false);
		imagesavealpha($sliced, true);
		$bgc = imagecolorallocatealpha($sliced, 0,0,0,127);
		imagefilledrectangle ($sliced, 0, 0, $width, $height, $bgc);

		$rx = $startX + $lenX;
		$rw = $sw - $rx;

		$ry = $startY + $lenY;
		$bh = $sh - $ry;

		$rdx = $width - $rw;
		$nxSize = $rdx - $startX;

		$rdy = $height - $bh;
		$nySize = $rdy - $startY;

		imagecopy       ($sliced, $im, 0, 0, 0, 0, $startX, $startY); // top left corner
		imagecopyresized($sliced, $im, $startX, 0, $startX, 0, $nxSize, $startY, $lenX, $startY); // top middle
		imagecopy       ($sliced, $im, $rdx, 0, $rx, 0, $rw, $startY); // top right corner

		imagecopyresized($sliced, $im, 0, $startY, 0, $startY, $startX, $nySize, $startX, $lenY); // left middle
		imagecopyresized($sliced, $im, $rdx, $startY, $rx, $startY, $rw, $nySize, $rw, $lenY); // right middle

		imagecopy       ($sliced, $im, 0, $rdy, 0, $ry, $startX, $bh); // bottom left corner
		imagecopyresized($sliced, $im, $startX, $rdy, $startX, $ry, $nxSize, $bh, $lenX, $bh); // bottom middle
		imagecopy       ($sliced, $im, $rdx, $rdy, $rx, $ry, $rw, $bh); // bottom right corner

		return $sliced;
	}

	function &openFile($file){
		$path_parts = pathinfo($file);

		switch (strtolower($path_parts['extension'])){
			case 'jpg':
			case 'jpeg':
				$im = @imagecreatefromjpeg($file);
			break;

			case 'png':
				$im = @imagecreatefrompng($file);
			break;

			case 'gif':
				$im = @imagecreatefromgif($file);
				if ($im){
					list($width, $height) = getimagesize($file);
					$image_p = imagecreatetruecolor ($width, $height);
					imagecopy($image_p, $im, 0, 0, 0, 0, $width, $height);
					imagedestroy($im);
					$im = $image_p;
				}

			break;

			default:
				$im = false;
		}

		if ($im === false) { // See if it failed
			$im = imagecreatetruecolor (200, 200);
			$bgc = imagecolorallocate ($im, 255, 255, 255);
			imagefilledrectangle ($im, 0, 0, 200, 200, $bgc);
			$tc = imagecolorallocate ($im, 0, 0, 0);
			imagestring ($im, 1, 5, 5, "Error loading $file", $tc);
		}

		return $im;
	}

    function &createThumbnail(&$im, $tWidth, $tHeight, $crop = false, $fill = false){
		$width = imagesx($im);
		$height = imagesy($im);
		$box = self::boxCalc($width, $height, $tWidth, $tHeight, $crop);

		if ($crop){
			$image_p = imagecreatetruecolor ($tWidth, $tHeight);

		} else {
			if ($fill === false){
				$image_p = imagecreatetruecolor ($box['w'], $box['h']);
				$box['x'] =  $box['y'] = 0;

			} else {
				$image_p = imagecreatetruecolor ($tWidth, $tHeight);
				$bgc = imagecolorallocate ($image_p, $fill[0], $fill[1], $fill[2]);
				imagefilledrectangle ($image_p, 0, 0, $tWidth, $tHeight, $bgc);

			}
		}

		imagecopyresampled($image_p, $im, $box['x'], $box['y'], $box['cx'], $box['cy'], $box['w'], $box['h'], $box['cw'], $box['ch']);
		return $image_p;
	}

	function saveImage(&$image, $file, $kind = 'jpg', $comp = 75){
		$path_parts = pathinfo($file);
		$ext = strtolower($path_parts['extension']);
		if (!strpos($file, $ext)) $file .= $ext;

		switch ($kind){
			case 'png':
				imagepng($image, $file);
			break;

			case 'jpg':
			default:
				imagejpeg($image, $file, $comp);
		}

		return $file;
	}

	function boxCalc($width, $height, $maxWidth, $maxHeight, $crop = false){
		$xPos = $cx = 0;
		$yPos = $cy = 0;

		$widthScale = $width / $maxWidth;
		$heightScale = $height / $maxHeight;

		$mw = $maxWidth;
		$mh = $maxHeight;
		$cw = $width;
		$ch = $height;

		if ($crop){
			$minScale = min($widthScale, $heightScale);

			if ($widthScale < $heightScale){
				$ch = $maxHeight * $minScale;
				$cy = (($height - $ch) / 2);

			} else {
				$cw = $maxWidth * $minScale;
				$cx = (($width - $cw) / 2);
			}

		} else {
			$maxScale = max($widthScale, $heightScale);

			if ($widthScale < $heightScale){
				$mw = $width / $maxScale;
				$xPos = (($maxWidth - $mw) / 2);

			} else {
				$mh = $height / $maxScale;
				$yPos = (($maxHeight - $mh) / 2);
			}
		}

		return array(	'x'=>round($xPos), 'y'=>round($yPos), 'w'=>round($mw), 'h'=>round($mh),
						'cx'=>round($cx), 'cy'=>round($cy), 'cw'=>round($cw), 'ch'=>round($ch));
	}
}

class Controller {
	function main($config){

		if (!isset($_REQUEST['action'])) exit();
		$action = $_REQUEST['action'];
		
		if (!isset($_REQUEST['path'])) exit();
		$path = $_REQUEST['path'];

		$fm = new FileManager($config);

		switch ($action){
			case 'createFolder':
				$ret = $fm->createFolder($path, $_REQUEST['name']);
				echo "ok=$ret&";
			break;

			case 'viewImage':
				$filename = $_REQUEST['name'];
				$info = $fm->img_info($path, $filename);

				$file = $fm->buildFilename($path, $filename);

				if ($config['thumbPath'] == '' || ($info['width'] < 210 && $info['height'] < 210)){
					$fp=fopen($file, 'rb');

					if ($info && $fp) {
						header("Content-type: {$info['mime']}");
						fpassthru($fp);
						exit();
					}

				} else {
					$thumbname = $fm->buildFilename($config['thumbPath'], sha1($file).'.jpg');
					if (!file_exists($thumbname)){
						$im = new ImageManagement();
						$img =& $im->openFile($file);
						$thumb =& $im->createThumbnail($img, 210, 210);
						$im->saveImage($thumb, $thumbname);
					}

					$fp=fopen($thumbname, 'rb');

					if ($fp) {
						header("Content-type: image/png");
						fpassthru($fp);
						exit();
					}
				}

			break;

			case 'uploadFile':
				$fm->upload($path);
			break;

			case 'deleteFile':
				$fm->delete($path, explode(',', $_REQUEST['files']));
			break;

			case 'getFileList':
				$images = (isset($_REQUEST['images']) && $_REQUEST['images']=='true') ? 'image' : null;
				$result = $fm->getDirList($path, false, $images);
				$ret = '<dir>';

				foreach ($result as $item){
					$ret .= '<item>';
					$ret .= '<name><![CDATA['.$item['name'].']]></name>';
					$ret .= '<kind>'.$item['kind'].'</kind>';
					$ret .= '<atime>'.$item['atime'].'</atime>';
					$ret .= '<mtime>'.$item['mtime'].'</mtime>';
					if (isset($item['size'])) $ret .= '<size>'.$item['size'].'</size>';

					if ($item['kind'] == 'folder') {
						$ret .= '<files>'.$item['files'].'</files>';
						$ret .= '<folders>'.$item['folders'].'</folders>';
					}

					if (isset($item['ext'])){
						$ext = $item['ext'];
						$filename = $item['name'];
						if ($ext == 'swf'){
							$info = $fm->swf_info($path, $filename);

							if ($info['valid'] === true){
								$ret .= '<info>';
								$ret .= '<compressed>'.$info['compressed'].'</compressed>';
								$ret .= '<version>'.$info['version'].'</version>';
								$ret .= '<size>'.$info['fsize'].'</size>';
								$ret .= '<width>'.$info['width'].'</width>';
								$ret .= '<height>'.$info['height'].'</height>';
								$ret .= '<fps>'.$info['fps'].'</fps>';
								$ret .= '<frames>'.$info['frames'].'</frames>';
								$ret .= '</info>';
							}

						} else if (in_array($ext, array('txt','htm','html','xml','ini','js', 'css'))){
								$ret .= '<info><text><![CDATA[';
								$ret .= htmlentities(implode("\n",$fm->txt_info($path, $filename)));
								$ret .= ']]></text></info>';

						} else if ($item['kind'] == 'image'){
							$ret .= '<info>';
							foreach ($fm->img_info($path, $filename) as $key=>$value){
								$ret .= "<$key>".$value."</$key>";
							}
							$ret .= '</info>';
						}
					}

					$ret .= '</item>';
				}

				$ret .= '</dir>';
				header('Content-type: text/xml');
				echo $ret;
			break;
		}
		
		exit();
	}
}

Controller::main($config);

?>