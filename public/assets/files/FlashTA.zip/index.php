<?php
header('Content-type: text/html; charset=UTF-8');
header('Cache-Control: no-cache, must-revalidate');
header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');

function removeQuotes($string){
	if (get_magic_quotes_gpc()) {
		$string = stripslashes($string);
	}

	return $string;
}

$fta = isset($_POST['flashtextarea']) ? removeQuotes($_POST['flashtextarea']) : '';
$nta = isset($_POST['normaltextarea']) ? removeQuotes($_POST['normaltextarea']) : '';

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<title>Test</title>
		<style type="text/css"><!--
/* This style will be applied to all replaced text areas */
.efx_form_flashtextarea {
	width: 100%;
}

/*	The filebrowser encloses the new input tag into a span, and adds a link for browsing.
	Here you can configure both the span and the link (button) */

.efx_form_fileBrowser_span{}

.efx_form_fileBrowser_button {
	padding-left: 16px;
	background: url("SubMenu.png") no-repeat;
	position: relative;
	top: -2px;
	cursor: hand;
}
		--></style>
		<script type="text/javascript" src="fTAR.js"></script>
	</head>
	<body>
		<div><?=$fta?></div>
		<form action="index.php?rnd=<? echo rand();?>" method="post">
			<textarea name="normaltextarea" rows="10" cols="50"><?=$fta?></textarea><br/>
			<label>Nice file selector for all files <input type="text" name="theBrowser1" value="test" class="efx_browser" /></label><br/>
			<label>Nice file selector for images only <input type="text" name="theBrowser2" value="test" class="efx_browser_images" /></label><br/>
			<input type="submit" name="fromflash" value="Submit!"/>
		</form>

		<form action="index.php?rnd=<? echo rand();?>" method="post">
			<textarea name="flashtextarea" class="efx_flashtextarea" rows="20" cols="70" ><?=$nta?></textarea><br/>
			<input type="submit" name="toflash" value="Submit!"/>
		</form>

  		<a href="#" onclick = "fTAR.FlashTextArea.getAreasChanged(); return false;">Changed Areas...</a>

	</body>
</html>